package FA;

public interface Shape {
	
	void shapeMaker();

}
