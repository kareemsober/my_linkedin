package FA;

public class AdminPortal {

}
