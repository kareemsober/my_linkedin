package FA;

public class Rectangle implements Shape {

	@Override
	public void shapeMaker() {
		System.out.println("Rectangle");

	}

}
