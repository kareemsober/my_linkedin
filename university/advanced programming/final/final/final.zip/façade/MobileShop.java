package FA.façade;

public interface MobileShop {  
    public void modelNo();  
    public void price();  
}