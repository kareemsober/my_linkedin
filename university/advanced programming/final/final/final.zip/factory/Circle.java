package FA.factory;

public class Circle implements Shape {

	@Override
	public void shapeMaker() {
		System.out.println("Circle");

	}

}
