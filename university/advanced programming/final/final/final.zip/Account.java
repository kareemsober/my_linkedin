package FA;

public interface Account {

	void editAccount();

	void removeAccount(Object obj);

}
