public interface TrackPrintingService {
    void print(Student student);
}
