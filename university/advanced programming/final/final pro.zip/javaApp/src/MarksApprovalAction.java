public interface MarksApprovalAction {
    void approveMark(Assessment assessment,Student student);
}
