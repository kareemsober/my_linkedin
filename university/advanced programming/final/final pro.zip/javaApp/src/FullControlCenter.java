public class FullControlCenter {
    ApplicationManagement applicationManagement=new ApplicationManagement();
    ObjectManagement objectManagement=new ObjectManagement();
    ApprovalManagement approvalManagement=new ApprovalManagement();
}
