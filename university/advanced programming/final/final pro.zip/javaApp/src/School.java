public class School extends EducationInstitution{
    public School(String id, String englishName, String arabicName) {
        super(id, englishName, arabicName);
    }

    public School() {
    }
}
