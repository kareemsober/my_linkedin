public class ProgramFactory {
    public Program createProgram(){
        return new Program();
    }
    public Program createProgram(String arabicName, String id, String englishName, School school){
        return new Program();
    }


}
