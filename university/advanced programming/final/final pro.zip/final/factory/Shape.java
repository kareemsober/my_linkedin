package FA.factory;

public interface Shape {
	
	void shapeMaker();

}
