package FA.factory;

public class Triangle implements Shape {

	@Override
	public void shapeMaker() {
		System.out.println("Triangle");

	}

}
