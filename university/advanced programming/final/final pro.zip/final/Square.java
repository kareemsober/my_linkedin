package FA;

public class Square implements Shape {

	@Override
	public void shapeMaker() {
		System.out.println("Square");

	}

}
