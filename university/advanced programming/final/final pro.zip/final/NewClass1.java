package FA;


public class NewClass1 {
}
