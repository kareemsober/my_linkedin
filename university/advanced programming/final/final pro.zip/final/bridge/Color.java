package FA.bridge;

public interface Color {
	public void applyColor();


}
